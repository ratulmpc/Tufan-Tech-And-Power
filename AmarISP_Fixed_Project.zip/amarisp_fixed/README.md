# AmarISP — Offline ISP Billing & Customer Manager

This project has been repaired from the supplied partial source archive. It now includes the missing Room entities/DAOs, launcher activity, Compose customer screens, theme resources, and consistent Gradle configuration.

## Features in this build
- Offline local customer database (Room/SQLite)
- Add PPPoE customers and track phone, area, package, speed, monthly bill and expiry date
- Customer totals, active count and total outstanding balance
- Record payments against outstanding balance
- Suspend/resume a customer and delete customer records
- Basic coordinate-based coverage canvas (not a live Google Earth map)
- Local AES-GCM helper for future PPPoE password storage

## Build
1. Install Android Studio (recent stable version) and Android SDK Platform 35.
2. Open this folder in Android Studio and let Gradle sync finish. Use JDK 17.
3. On a computer with internet access, run `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`). The included launcher downloads Gradle 8.7 on first use if it is not cached.
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Important notes
- The original archive was missing `MainActivity`, several Room entity/DAO files, Android theme resources, Gradle version-catalog files, and the standard Gradle wrapper JAR. This repair supplies the missing source/resources and a small Gradle launcher.
- I could not execute a full Android build in this environment because Android SDK/Gradle are not installed and external network access is unavailable. Please run the build in Android Studio; if it reports any remaining error, send the complete Build output and I can correct it.
- This is a repaired working starter, not a complete ISP production system: it does not yet connect to a MikroTik/RouterOS router, send expiry notifications, export KML, or create real Google Maps tiles. The coverage view is a simple coordinate plot. Keep a backup before testing with real customer records.
