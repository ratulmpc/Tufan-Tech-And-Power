@echo off
setlocal
set GV=8.7
set CACHE=%USERPROFILE%\.gradle\amarisp-bootstrap\gradle-%GV%
set BIN=%CACHE%\gradle-%GV%\bin\gradle.bat
if not exist "%BIN%" (
  if not exist "%CACHE%" mkdir "%CACHE%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GV%-bin.zip' -OutFile '%CACHE%\gradle.zip'; Expand-Archive -Force '%CACHE%\gradle.zip' '%CACHE%'"
  if errorlevel 1 exit /b 1
)
call "%BIN%" -p "%~dp0" %*
