# Keep default Android/Room rules. Minification is disabled for the first stable build.
