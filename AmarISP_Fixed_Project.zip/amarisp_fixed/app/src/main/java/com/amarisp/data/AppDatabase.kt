package com.amarisp.data

import android.content.Context
import androidx.room.*

@Database(
    entities = [
        CustomerEntity::class,
        PaymentEntity::class,
        SuspensionEntity::class,
        InfrastructureNodeEntity::class,
        FiberLinkEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao
    abstract fun paymentDao(): PaymentDao
    abstract fun suspensionDao(): SuspensionDao
    abstract fun infrastructureDao(): InfrastructureDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "amar_isp_offline.db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
