package com.amarisp.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import com.amarisp.data.CustomerEntity

@Composable
fun EarthMapScreen(
    customers: List<CustomerEntity>,
    onSelectCustomer: (CustomerEntity) -> Unit,
    onUpdateLocation: (String, Double, Double) -> Unit
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Box(modifier = Modifier.fillMaxSize()) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.5f, 5f)
                        offset += pan
                    }
                }
        ) {
            // Draw Space/Dark Earth Lattice Grid
            drawRect(color = Color(0xFF060D1A))

            // Render Customers with LED Status Indicators
            customers.forEach { cust ->
                val ledColor = when (cust.status) {
                    "active" -> Color(0xFF10B981)   // 🟢 Active Green
                    "suspended" -> Color(0xFFF59E0B) // 🟠 Suspended Orange (3D/7D)
                    "inactive" -> Color(0xFF94A3B8)  // ⚪ Inactive Grey
                    else -> Color(0xFFEF4444)        // 🔴 Disabled Red
                }

                val screenX = (cust.longitude.toFloat() - 90.38f) * 20000f * scale + size.width / 2 + offset.x
                val screenY = -(cust.latitude.toFloat() - 23.82f) * 20000f * scale + size.height / 2 + offset.y

                // Outer Glowing Ring
                drawCircle(
                    color = ledColor.copy(alpha = 0.35f),
                    radius = 16f * scale,
                    center = Offset(screenX, screenY)
                )

                // Core LED Pin
                drawCircle(
                    color = ledColor,
                    radius = 8f * scale,
                    center = Offset(screenX, screenY)
                )
            }
        }
    }
}
