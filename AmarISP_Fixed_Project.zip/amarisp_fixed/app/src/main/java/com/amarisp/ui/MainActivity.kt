package com.amarisp.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.amarisp.data.AppDatabase
import com.amarisp.data.CustomerEntity
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collectLatest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.getDatabase(applicationContext)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF2563EB), secondary = androidx.compose.ui.graphics.Color(0xFF10B981))) {
                var customers by remember { mutableStateOf(emptyList<CustomerEntity>()) }
                var showAdd by remember { mutableStateOf(false) }
                var showMap by remember { mutableStateOf(false) }
                LaunchedEffect(Unit) { db.customerDao().getAllCustomers().collectLatest { customers = it } }
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(Modifier.fillMaxSize().padding(16.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("AmarISP", style = MaterialTheme.typography.headlineMedium)
                                Text("Offline Billing & Customer Manager", style = MaterialTheme.typography.bodySmall)
                            }
                            Text("৳", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SummaryCard("Customers", customers.size.toString(), Modifier.weight(1f))
                            SummaryCard("Active", customers.count { it.status == "active" }.toString(), Modifier.weight(1f))
                            SummaryCard("Due", "৳${customers.sumOf { it.dueAmountBdt }.toInt()}", Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { showAdd = true }) { Text("+ Add customer") }
                            OutlinedButton(onClick = { showMap = !showMap }) { Text(if (showMap) "Customers" else "Coverage map") }
                        }
                        Spacer(Modifier.height(8.dp))
                        if (showMap) {
                            EarthMapScreen(customers, onSelectCustomer = {}, onUpdateLocation = { id, lat, lng -> lifecycleScope.launch { db.customerDao().updateCoordinates(id, lat, lng) } })
                        } else if (customers.isEmpty()) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("No customers yet", style = MaterialTheme.typography.titleLarge)
                                    Text("Add your first PPPoE customer to get started.")
                                }
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(customers, key = { it.id }) { customer ->
                                    CustomerCard(customer,
                                        onStatus = { status -> lifecycleScope.launch { db.customerDao().updateStatus(customer.id, status) } },
                                        onDelete = { lifecycleScope.launch { db.customerDao().deleteCustomer(customer) } },
                                        onPay = { amount -> lifecycleScope.launch { db.customerDao().deductDue(customer.id, amount) } })
                                }
                            }
                        }
                    }
                }
                if (showAdd) AddCustomerDialog(onDismiss = { showAdd = false }, onSave = { customer ->
                    lifecycleScope.launch { db.customerDao().insertCustomer(customer) }
                    showAdd = false
                })
            }
        }
    }
}

@Composable private fun SummaryCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp)) { Text(label, style = MaterialTheme.typography.labelMedium); Text(value, style = MaterialTheme.typography.titleLarge) }
    }
}

@Composable private fun CustomerCard(customer: CustomerEntity, onStatus: (String) -> Unit, onDelete: () -> Unit, onPay: (Double) -> Unit) {
    var payment by remember { mutableStateOf("") }
    val statusColor = when (customer.status) { "active" -> androidx.compose.ui.graphics.Color(0xFF10B981); "suspended" -> androidx.compose.ui.graphics.Color(0xFFF59E0B); else -> androidx.compose.ui.graphics.Color(0xFF64748B) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(customer.fullName, style = MaterialTheme.typography.titleMedium)
                    Text("${customer.id} • ${customer.pppoeUsername}", style = MaterialTheme.typography.bodySmall)
                    Text("${customer.phone} • ${customer.area}", style = MaterialTheme.typography.bodySmall)
                }
                Text(customer.status.uppercase(), color = statusColor, style = MaterialTheme.typography.labelMedium)
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column { Text("Monthly: ৳${customer.monthlyBillBdt.toInt()}"); Text("Due: ৳${customer.dueAmountBdt.toInt()}", color = MaterialTheme.colorScheme.error) }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { onStatus(if (customer.status == "active") "suspended" else "active") }) { Text(if (customer.status == "active") "Suspend" else "Resume") }
                    TextButton(onClick = onDelete) { Text("Delete") }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(value = payment, onValueChange = { payment = it.filter { c -> c.isDigit() || c == '.' } }, modifier = Modifier.weight(1f), label = { Text("Payment ৳") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                Button(onClick = { payment.toDoubleOrNull()?.takeIf { it > 0 }?.let { onPay(it); payment = "" } }) { Text("Record") }
            }
        }
    }
}

@Composable private fun AddCustomerDialog(onDismiss: () -> Unit, onSave: (CustomerEntity) -> Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }; var area by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }; var pkg by remember { mutableStateOf("Basic") }
    var speed by remember { mutableStateOf("20 Mbps") }; var bill by remember { mutableStateOf("800") }
    var expiry by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add PPPoE customer") }, text = {
        Column(Modifier.heightIn(max = 520.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Full name *") }, singleLine = true)
            OutlinedTextField(phone, { phone = it }, label = { Text("Phone") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
            OutlinedTextField(address, { address = it }, label = { Text("Address") }, singleLine = true)
            OutlinedTextField(area, { area = it }, label = { Text("Area") }, singleLine = true)
            OutlinedTextField(username, { username = it }, label = { Text("PPPoE username *") }, singleLine = true)
            OutlinedTextField(pkg, { pkg = it }, label = { Text("Package") }, singleLine = true)
            OutlinedTextField(speed, { speed = it }, label = { Text("Speed") }, singleLine = true)
            OutlinedTextField(bill, { bill = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Monthly bill (BDT)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            OutlinedTextField(expiry, { expiry = it }, label = { Text("Expiry date (YYYY-MM-DD)") }, singleLine = true)
        }
    }, confirmButton = { Button(enabled = name.isNotBlank() && username.isNotBlank(), onClick = {
        val now = System.currentTimeMillis(); val amount = bill.toDoubleOrNull() ?: 0.0
        onSave(CustomerEntity(id = "ISP-${now}", fullName = name.trim(), phone = phone.trim(), address = address.trim(), area = area.trim(), latitude = 23.82, longitude = 90.38, pppoeUsername = username.trim(), encryptedPppoePassword = null, packageName = pkg.trim(), packageSpeed = speed.trim(), monthlyBillBdt = amount, dueAmountBdt = amount, connectionDate = expiry, billingDueDate = expiry, expiryDate = expiry, status = "active", connectedNodeId = null, notes = null, createdAt = now, updatedAt = now))
    }) { Text("Save customer") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}
