package com.amarisp.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY fullName ASC")
    fun getAllCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getCustomerById(id: String): CustomerEntity?

    @Query("SELECT * FROM customers WHERE status = :status")
    fun getCustomersByStatus(status: String): Flow<List<CustomerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: CustomerEntity)

    @Update
    suspend fun updateCustomer(customer: CustomerEntity)

    @Query("UPDATE customers SET latitude = :lat, longitude = :lng WHERE id = :id")
    suspend fun updateCoordinates(id: String, lat: Double, lng: Double)

    @Query("UPDATE customers SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: String, status: String)

    @Query("UPDATE customers SET dueAmountBdt = dueAmountBdt + :amount WHERE status != 'disabled'")
    suspend fun applyMonthlyBilling(amount: Double)

    @Query("UPDATE customers SET dueAmountBdt = MAX(0.0, dueAmountBdt - :paidAmount) WHERE id = :id")
    suspend fun deductDue(id: String, paidAmount: Double)

    @Delete
    suspend fun deleteCustomer(customer: CustomerEntity)
}
