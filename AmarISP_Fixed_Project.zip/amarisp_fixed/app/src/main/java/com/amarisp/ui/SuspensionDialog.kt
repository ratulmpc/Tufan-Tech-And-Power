package com.amarisp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.time.LocalDate

@Composable
fun SuspensionDialog(
    customerId: String,
    customerName: String,
    onDismiss: () -> Unit,
    onApplySuspension: (days: Int, reason: String) -> Unit,
    onResumeService: () -> Unit
) {
    var selectedDays by remember { mutableIntStateOf(7) }
    var reason by remember { mutableStateOf("Bill overdue grace expired") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Service Suspension Controls") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Customer: $customerName")
                Text("Select suspension duration:")

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { selectedDays = 3 },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedDays == 3) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Text("3-Day Hold")
                    }

                    Button(
                        onClick = { selectedDays = 7 },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedDays == 7) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Text("7-Day Grace")
                    }
                }

                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Suspension Reason") }
                )
            }
        },
        confirmButton = {
            Button(onClick = { onApplySuspension(selectedDays, reason) }) {
                Text("Apply Suspension")
            }
        },
        dismissButton = {
            TextButton(onClick = onResumeService) {
                Text("Resume Service")
            }
        }
    )
}
