package com.amarisp.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "payments",
    indices = [
        Index(value = ["customerId"]),
        Index(value = ["receiptNo"], unique = true)
    ]
)
data class PaymentEntity(
    @PrimaryKey
    val id: String,
    val receiptNo: String,
    val customerId: String,
    val customerName: String,
    val amountBdt: Double,
    val paymentDate: String,
    val billingMonth: String,
    val method: String, // "bkash", "nagad", "cash", "bank_transfer"
    val trxId: String?,
    val collectedBy: String,
    val notes: String?,
    val timestamp: Long = System.currentTimeMillis()
)
