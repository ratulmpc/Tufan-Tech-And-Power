package com.amarisp.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

@Entity(
    tableName = "customers",
    indices = [
        Index(value = ["pppoeUsername"], unique = true),
        Index(value = ["phone"]),
        Index(value = ["status"])
    ]
)
data class CustomerEntity(
    @PrimaryKey
    val id: String, // e.g. BD-ISP-1001
    val fullName: String,
    val phone: String,
    val address: String,
    val area: String,
    val latitude: Double,
    val longitude: Double,
    val pppoeUsername: String,
    val encryptedPppoePassword: String?, // Encrypted via Android Keystore
    val packageName: String,
    val packageSpeed: String,
    val monthlyBillBdt: Double,
    val dueAmountBdt: Double,
    val connectionDate: String,
    val billingDueDate: String,
    val expiryDate: String,
    val status: String, // "active", "suspended", "inactive", "disabled"
    val connectedNodeId: String?,
    val notes: String?,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
