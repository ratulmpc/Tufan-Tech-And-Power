package com.amarisp.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "suspensions", indices = [Index("customerId")])
data class SuspensionEntity(
    @PrimaryKey val id: String,
    val customerId: String,
    val startDate: String,
    val endDate: String,
    val reason: String,
    val isActive: Boolean = true
)

@Entity(tableName = "infrastructure_nodes", indices = [Index("type")])
data class InfrastructureNodeEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String,
    val latitude: Double,
    val longitude: Double,
    val parentNodeId: String? = null,
    val notes: String? = null
)

@Entity(tableName = "fiber_links", indices = [Index("fromNodeId"), Index("toNodeId")])
data class FiberLinkEntity(
    @PrimaryKey val id: String,
    val fromNodeId: String,
    val toNodeId: String,
    val cableType: String = "Fiber",
    val lengthMeters: Double = 0.0,
    val estimatedLossDb: Double = 0.0
)

class Converters
