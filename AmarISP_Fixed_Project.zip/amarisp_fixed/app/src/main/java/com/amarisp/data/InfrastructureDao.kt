package com.amarisp.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SuspensionDao {
    @Query("SELECT * FROM suspensions ORDER BY startDate DESC") fun getAll(): Flow<List<SuspensionEntity>>
    @Query("SELECT * FROM suspensions WHERE customerId = :customerId AND isActive = 1") fun activeForCustomer(customerId: String): Flow<List<SuspensionEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: SuspensionEntity)
    @Update suspend fun update(item: SuspensionEntity)
}

@Dao
interface InfrastructureDao {
    @Query("SELECT * FROM infrastructure_nodes ORDER BY name") fun getNodes(): Flow<List<InfrastructureNodeEntity>>
    @Query("SELECT * FROM fiber_links ORDER BY id") fun getLinks(): Flow<List<FiberLinkEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertNode(node: InfrastructureNodeEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertLink(link: FiberLinkEntity)
    @Delete suspend fun deleteNode(node: InfrastructureNodeEntity)
}

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments ORDER BY timestamp DESC") fun getAllPayments(): Flow<List<PaymentEntity>>
    @Query("SELECT * FROM payments WHERE customerId = :customerId ORDER BY timestamp DESC") fun getPaymentsForCustomer(customerId: String): Flow<List<PaymentEntity>>
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertPayment(payment: PaymentEntity)
    @Query("SELECT COALESCE(SUM(amountBdt), 0) FROM payments WHERE billingMonth = :month") suspend fun totalCollectedForMonth(month: String): Double
}
