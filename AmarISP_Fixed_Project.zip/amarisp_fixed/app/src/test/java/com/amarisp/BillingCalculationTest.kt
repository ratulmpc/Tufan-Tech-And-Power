package com.amarisp

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class BillingCalculationTest {

    @Test
    fun testPaymentDeductionReducesDueCorrectly() {
        val initialDue = 1600.0
        val paymentAmount = 800.0
        val remainingDue = Math.max(0.0, initialDue - paymentAmount)
        assertEquals(800.0, remainingDue, 0.01)
    }

    @Test
    fun testExcessPaymentDoesNotProduceNegativeDue() {
        val initialDue = 500.0
        val paymentAmount = 1000.0
        val remainingDue = Math.max(0.0, initialDue - paymentAmount)
        assertEquals(0.0, remainingDue, 0.01)
    }

    @Test
    fun testSuspensionDurationCalculation() {
        val startDate = LocalDate.of(2026, 10, 15)
        val threeDayEnd = startDate.plusDays(3)
        val sevenDayEnd = startDate.plusDays(7)

        assertEquals(LocalDate.of(2026, 10, 18), threeDayEnd)
        assertEquals(LocalDate.of(2026, 10, 22), sevenDayEnd)
    }
}
